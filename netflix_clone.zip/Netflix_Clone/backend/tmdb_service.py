import os
import requests
from typing import List, Dict, Optional
import logging
import random

logger = logging.getLogger(__name__)

# TMDB API Keys (rotate if rate limited)
TMDB_API_KEYS = [
    'c8dea14dc917687ac631a52620e4f7ad',
    '3cb41ecea3bf606c56552db3d17adefd'
]

TMDB_BASE_URL = 'https://api.themoviedb.org/3'
TMDB_IMAGE_BASE_URL = 'https://image.tmdb.org/t/p'

current_key_index = 0

def get_api_key():
    """Get current TMDB API key with rotation support"""
    global current_key_index
    return TMDB_API_KEYS[current_key_index]

def rotate_api_key():
    """Rotate to next API key if rate limited"""
    global current_key_index
    current_key_index = (current_key_index + 1) % len(TMDB_API_KEYS)
    logger.info(f"Rotated to API key index: {current_key_index}")

def make_tmdb_request(endpoint: str, params: Dict = None) -> Optional[Dict]:
    """Make a request to TMDB API with error handling"""
    if params is None:
        params = {}
    
    params['api_key'] = get_api_key()
    url = f"{TMDB_BASE_URL}{endpoint}"
    
    try:
        response = requests.get(url, params=params, timeout=10)
        
        if response.status_code == 429:  # Rate limited
            logger.warning("TMDB API rate limit hit, rotating key")
            rotate_api_key()
            params['api_key'] = get_api_key()
            response = requests.get(url, params=params, timeout=10)
        
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        logger.error(f"TMDB API request failed: {e}")
        return None

def get_movie_trailer(movie_id: int, media_type: str = 'movie') -> Optional[str]:
    """Get YouTube trailer ID for a movie/show"""
    endpoint = f"/{media_type}/{movie_id}/videos"
    data = make_tmdb_request(endpoint)
    
    if not data or 'results' not in data:
        return None
    
    # Find YouTube trailer
    for video in data['results']:
        if video.get('site') == 'YouTube' and video.get('type') in ['Trailer', 'Teaser']:
            return video['key']
    
    # Return first YouTube video if no trailer found
    for video in data['results']:
        if video.get('site') == 'YouTube':
            return video['key']
    
    return None

def format_movie_data(item: Dict, media_type: str = None, include_trailer: bool = False) -> Dict:
    """Format TMDB movie/show data to our structure"""
    # Determine media type if not provided
    if not media_type:
        media_type = item.get('media_type', 'movie')
    
    # Get title (different field for TV shows)
    title = item.get('title') or item.get('name', 'Unknown')
    
    # Get release year
    release_date = item.get('release_date') or item.get('first_air_date', '')
    year = release_date.split('-')[0] if release_date else 'N/A'
    
    # Get trailer only if requested
    trailer = None
    if include_trailer:
        movie_id = item.get('id')
        trailer = get_movie_trailer(movie_id, media_type) if movie_id else None
    
    return {
        'id': item.get('id'),
        'title': title,
        'poster': f"{TMDB_IMAGE_BASE_URL}/w500{item.get('poster_path')}" if item.get('poster_path') else None,
        'backdrop': f"{TMDB_IMAGE_BASE_URL}/original{item.get('backdrop_path')}" if item.get('backdrop_path') else None,
        'rating': round(item.get('vote_average', 0), 1),
        'year': year,
        'description': item.get('overview', ''),
        'trailer': trailer
    }

def get_trending_content(limit: int = 20) -> List[Dict]:
    """Get trending movies and TV shows"""
    data = make_tmdb_request('/trending/all/week')
    
    if not data or 'results' not in data:
        return []
    
    results = []
    for item in data['results'][:limit]:
        formatted = format_movie_data(item)
        if formatted['poster']:  # Only include items with valid posters
            results.append(formatted)
    
    return results

def get_popular_movies(limit: int = 20) -> List[Dict]:
    """Get popular movies"""
    data = make_tmdb_request('/movie/popular')
    
    if not data or 'results' not in data:
        return []
    
    results = []
    for item in data['results'][:limit]:
        formatted = format_movie_data(item, 'movie')
        if formatted['poster']:
            results.append(formatted)
    
    return results

def get_top_rated_movies(limit: int = 20) -> List[Dict]:
    """Get top rated movies"""
    data = make_tmdb_request('/movie/top_rated')
    
    if not data or 'results' not in data:
        return []
    
    results = []
    for item in data['results'][:limit]:
        formatted = format_movie_data(item, 'movie')
        if formatted['poster']:
            results.append(formatted)
    
    return results

def get_action_movies(limit: int = 20) -> List[Dict]:
    """Get action movies (genre 28)"""
    params = {'with_genres': 28, 'sort_by': 'popularity.desc'}
    data = make_tmdb_request('/discover/movie', params)
    
    if not data or 'results' not in data:
        return []
    
    results = []
    for item in data['results'][:limit]:
        formatted = format_movie_data(item, 'movie')
        if formatted['poster']:
            results.append(formatted)
    
    return results

def get_tv_shows(limit: int = 20) -> List[Dict]:
    """Get popular TV shows"""
    data = make_tmdb_request('/tv/popular')
    
    if not data or 'results' not in data:
        return []
    
    results = []
    for item in data['results'][:limit]:
        formatted = format_movie_data(item, 'tv')
        if formatted['poster']:
            results.append(formatted)
    
    return results

def get_featured_content() -> Optional[Dict]:
    """Get a featured movie/show for the hero section"""
    # Get trending content and pick a random one with good rating
    data = make_tmdb_request('/trending/all/week')
    
    if not data or 'results' not in data:
        return None
    
    # Filter for high-rated content with backdrop
    candidates = [
        item for item in data['results']
        if item.get('vote_average', 0) >= 7.5 and item.get('backdrop_path')
    ]
    
    if not candidates:
        candidates = [item for item in data['results'] if item.get('backdrop_path')]
    
    if not candidates:
        return None
    
    # Pick a random featured item
    featured_item = random.choice(candidates[:10])
    
    # Get media type
    media_type = featured_item.get('media_type', 'movie')
    title = featured_item.get('title') or featured_item.get('name', 'Unknown')
    
    # Get release year
    release_date = featured_item.get('release_date') or featured_item.get('first_air_date', '')
    year = release_date.split('-')[0] if release_date else 'N/A'
    
    # Get genres
    genre_ids = featured_item.get('genre_ids', [])
    genre_map = {
        28: 'Action', 12: 'Adventure', 16: 'Animation', 35: 'Comedy',
        80: 'Crime', 99: 'Documentary', 18: 'Drama', 10751: 'Family',
        14: 'Fantasy', 36: 'History', 27: 'Horror', 10402: 'Music',
        9648: 'Mystery', 10749: 'Romance', 878: 'Sci-Fi', 10770: 'TV Movie',
        53: 'Thriller', 10752: 'War', 37: 'Western'
    }
    genres = [genre_map.get(gid, '') for gid in genre_ids[:3] if gid in genre_map]
    
    # Get trailer (fetch for featured content only)
    movie_id = featured_item.get('id')
    trailer = get_movie_trailer(movie_id, media_type) if movie_id else None
    
    # Get rating (content rating like PG-13, TV-14)
    rating = 'TV-14' if media_type == 'tv' else 'PG-13'
    
    return {
        'id': featured_item.get('id'),
        'title': title,
        'description': featured_item.get('overview', ''),
        'backdrop': f"{TMDB_IMAGE_BASE_URL}/original{featured_item.get('backdrop_path')}",
        'logo': None,  # TMDB doesn't provide logos easily
        'rating': rating,
        'year': year,
        'genres': genres,
        'trailer': trailer,
        'seasons': f"{featured_item.get('number_of_seasons', 1)} Seasons" if media_type == 'tv' else None
    }

def get_all_movie_rows() -> List[Dict]:
    """Get all movie rows for the homepage"""
    return [
        {
            'id': 1,
            'title': 'Trending Now',
            'movies': get_trending_content(20)
        },
        {
            'id': 2,
            'title': 'Popular on Netflix',
            'movies': get_popular_movies(20)
        },
        {
            'id': 3,
            'title': 'Top Rated',
            'movies': get_top_rated_movies(20)
        },
        {
            'id': 4,
            'title': 'Action & Adventure',
            'movies': get_action_movies(20)
        },
        {
            'id': 5,
            'title': 'TV Shows',
            'movies': get_tv_shows(20)
        }
    ]