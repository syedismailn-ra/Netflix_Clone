#!/usr/bin/env python3
"""
Netflix Clone Backend API Testing Suite
Tests all backend endpoints for the Netflix clone application
"""

import requests
import json
import time
from typing import Dict, List, Optional
import sys
import os

# Get backend URL from environment
BACKEND_URL = "https://trailertv-75.preview.emergentagent.com/api"

class NetflixBackendTester:
    def __init__(self):
        self.base_url = BACKEND_URL
        self.session = requests.Session()
        self.session.timeout = 10
        self.test_results = []
        
    def log_test(self, test_name: str, passed: bool, message: str = "", response_data: Dict = None):
        """Log test result"""
        result = {
            "test": test_name,
            "passed": passed,
            "message": message,
            "timestamp": time.time()
        }
        if response_data:
            result["response_sample"] = response_data
        self.test_results.append(result)
        
        status = "✅ PASS" if passed else "❌ FAIL"
        print(f"{status} {test_name}: {message}")
        
    def test_featured_endpoint(self):
        """Test GET /api/featured endpoint"""
        print("\n=== Testing Featured Content Endpoint ===")
        
        try:
            start_time = time.time()
            response = self.session.get(f"{self.base_url}/featured")
            response_time = time.time() - start_time
            
            # Test response status
            if response.status_code != 200:
                self.log_test("Featured - Status Code", False, f"Expected 200, got {response.status_code}")
                return
            
            self.log_test("Featured - Status Code", True, f"200 OK (Response time: {response_time:.2f}s)")
            
            # Test response time
            if response_time > 5:
                self.log_test("Featured - Response Time", False, f"Response time {response_time:.2f}s > 5s")
            else:
                self.log_test("Featured - Response Time", True, f"Response time {response_time:.2f}s < 5s")
            
            # Parse JSON
            try:
                data = response.json()
            except json.JSONDecodeError:
                self.log_test("Featured - JSON Parse", False, "Invalid JSON response")
                return
            
            self.log_test("Featured - JSON Parse", True, "Valid JSON response")
            
            # Test required fields
            required_fields = ['title', 'description', 'backdrop', 'genres', 'year', 'trailer']
            missing_fields = []
            
            for field in required_fields:
                if field not in data:
                    missing_fields.append(field)
            
            if missing_fields:
                self.log_test("Featured - Required Fields", False, f"Missing fields: {missing_fields}")
            else:
                self.log_test("Featured - Required Fields", True, "All required fields present")
            
            # Test backdrop URL format
            if 'backdrop' in data and data['backdrop']:
                if data['backdrop'].startswith('https://image.tmdb.org/t/p/'):
                    self.log_test("Featured - Backdrop URL", True, "Valid TMDB image URL")
                else:
                    self.log_test("Featured - Backdrop URL", False, f"Invalid backdrop URL: {data['backdrop']}")
            else:
                self.log_test("Featured - Backdrop URL", False, "No backdrop URL provided")
            
            # Test genres format
            if 'genres' in data and isinstance(data['genres'], list):
                self.log_test("Featured - Genres Format", True, f"Genres list with {len(data['genres'])} items")
            else:
                self.log_test("Featured - Genres Format", False, "Genres should be a list")
            
            # Test year format
            if 'year' in data and data['year'] and data['year'] != 'N/A':
                try:
                    year_int = int(data['year'])
                    if 1900 <= year_int <= 2030:
                        self.log_test("Featured - Year Format", True, f"Valid year: {data['year']}")
                    else:
                        self.log_test("Featured - Year Format", False, f"Year out of range: {data['year']}")
                except ValueError:
                    self.log_test("Featured - Year Format", False, f"Invalid year format: {data['year']}")
            else:
                self.log_test("Featured - Year Format", False, "No valid year provided")
            
            # Store sample for reference
            self.log_test("Featured - Sample Data", True, "Featured content retrieved", {
                "title": data.get('title', 'N/A'),
                "year": data.get('year', 'N/A'),
                "genres": data.get('genres', []),
                "has_trailer": bool(data.get('trailer'))
            })
            
        except requests.exceptions.RequestException as e:
            self.log_test("Featured - Network", False, f"Network error: {str(e)}")
        except Exception as e:
            self.log_test("Featured - General", False, f"Unexpected error: {str(e)}")
    
    def test_movie_rows_endpoint(self):
        """Test GET /api/movies/rows endpoint"""
        print("\n=== Testing Movie Rows Endpoint ===")
        
        try:
            start_time = time.time()
            response = self.session.get(f"{self.base_url}/movies/rows")
            response_time = time.time() - start_time
            
            # Test response status
            if response.status_code != 200:
                self.log_test("Movie Rows - Status Code", False, f"Expected 200, got {response.status_code}")
                return
            
            self.log_test("Movie Rows - Status Code", True, f"200 OK (Response time: {response_time:.2f}s)")
            
            # Test response time
            if response_time > 5:
                self.log_test("Movie Rows - Response Time", False, f"Response time {response_time:.2f}s > 5s")
            else:
                self.log_test("Movie Rows - Response Time", True, f"Response time {response_time:.2f}s < 5s")
            
            # Parse JSON
            try:
                data = response.json()
            except json.JSONDecodeError:
                self.log_test("Movie Rows - JSON Parse", False, "Invalid JSON response")
                return
            
            self.log_test("Movie Rows - JSON Parse", True, "Valid JSON response")
            
            # Test if data is a list
            if not isinstance(data, list):
                self.log_test("Movie Rows - Format", False, "Response should be a list of rows")
                return
            
            # Test number of rows (should be 5)
            if len(data) != 5:
                self.log_test("Movie Rows - Count", False, f"Expected 5 rows, got {len(data)}")
            else:
                self.log_test("Movie Rows - Count", True, "5 movie rows returned")
            
            # Test each row structure
            expected_titles = ['Trending Now', 'Popular on Netflix', 'Top Rated', 'Action & Adventure', 'TV Shows']
            
            for i, row in enumerate(data):
                row_name = f"Row {i+1}"
                
                # Test row structure
                if not isinstance(row, dict):
                    self.log_test(f"{row_name} - Structure", False, "Row should be a dictionary")
                    continue
                
                # Test required row fields
                if 'title' not in row or 'movies' not in row:
                    self.log_test(f"{row_name} - Fields", False, "Row missing title or movies field")
                    continue
                
                self.log_test(f"{row_name} - Fields", True, f"Title: {row['title']}")
                
                # Test movies list
                movies = row.get('movies', [])
                if not isinstance(movies, list):
                    self.log_test(f"{row_name} - Movies Format", False, "Movies should be a list")
                    continue
                
                if len(movies) == 0:
                    self.log_test(f"{row_name} - Movies Count", False, "No movies in row")
                    continue
                
                self.log_test(f"{row_name} - Movies Count", True, f"{len(movies)} movies")
                
                # Test first movie structure
                if movies:
                    movie = movies[0]
                    required_movie_fields = ['id', 'title', 'poster', 'rating', 'year']
                    missing_movie_fields = [field for field in required_movie_fields if field not in movie]
                    
                    if missing_movie_fields:
                        self.log_test(f"{row_name} - Movie Fields", False, f"Missing: {missing_movie_fields}")
                    else:
                        self.log_test(f"{row_name} - Movie Fields", True, "All required movie fields present")
                    
                    # Test poster URL
                    if movie.get('poster') and movie['poster'].startswith('https://image.tmdb.org/t/p/'):
                        self.log_test(f"{row_name} - Poster URL", True, "Valid TMDB poster URL")
                    else:
                        self.log_test(f"{row_name} - Poster URL", False, f"Invalid poster URL: {movie.get('poster')}")
            
            # Store sample data
            sample_data = {
                "total_rows": len(data),
                "row_titles": [row.get('title', 'N/A') for row in data],
                "total_movies": sum(len(row.get('movies', [])) for row in data)
            }
            self.log_test("Movie Rows - Sample Data", True, "Movie rows retrieved", sample_data)
            
        except requests.exceptions.RequestException as e:
            self.log_test("Movie Rows - Network", False, f"Network error: {str(e)}")
        except Exception as e:
            self.log_test("Movie Rows - General", False, f"Unexpected error: {str(e)}")
    
    def test_trailer_endpoint(self):
        """Test GET /api/movies/{movie_id}/trailer endpoint"""
        print("\n=== Testing Trailer Endpoint ===")
        
        # Test with a known movie ID (The Shawshank Redemption)
        test_cases = [
            {"movie_id": 278, "media_type": "movie", "name": "Movie Trailer"},
            {"movie_id": 1399, "media_type": "tv", "name": "TV Show Trailer"}
        ]
        
        for test_case in test_cases:
            movie_id = test_case["movie_id"]
            media_type = test_case["media_type"]
            test_name = test_case["name"]
            
            try:
                start_time = time.time()
                url = f"{self.base_url}/movies/{movie_id}/trailer?media_type={media_type}"
                response = self.session.get(url)
                response_time = time.time() - start_time
                
                # Test response status
                if response.status_code != 200:
                    self.log_test(f"{test_name} - Status Code", False, f"Expected 200, got {response.status_code}")
                    continue
                
                self.log_test(f"{test_name} - Status Code", True, f"200 OK (Response time: {response_time:.2f}s)")
                
                # Test response time
                if response_time > 5:
                    self.log_test(f"{test_name} - Response Time", False, f"Response time {response_time:.2f}s > 5s")
                else:
                    self.log_test(f"{test_name} - Response Time", True, f"Response time {response_time:.2f}s < 5s")
                
                # Parse JSON
                try:
                    data = response.json()
                except json.JSONDecodeError:
                    self.log_test(f"{test_name} - JSON Parse", False, "Invalid JSON response")
                    continue
                
                self.log_test(f"{test_name} - JSON Parse", True, "Valid JSON response")
                
                # Test response structure
                if 'trailer' not in data:
                    self.log_test(f"{test_name} - Structure", False, "Missing 'trailer' field")
                    continue
                
                self.log_test(f"{test_name} - Structure", True, "Correct response structure")
                
                # Test trailer value
                trailer = data['trailer']
                if trailer is None:
                    self.log_test(f"{test_name} - Trailer Value", True, "No trailer available (null)")
                elif isinstance(trailer, str) and len(trailer) > 0:
                    # YouTube video IDs are typically 11 characters
                    if len(trailer) == 11:
                        self.log_test(f"{test_name} - Trailer Value", True, f"Valid YouTube ID: {trailer}")
                    else:
                        self.log_test(f"{test_name} - Trailer Value", True, f"Trailer ID: {trailer} (length: {len(trailer)})")
                else:
                    self.log_test(f"{test_name} - Trailer Value", False, f"Invalid trailer value: {trailer}")
                
            except requests.exceptions.RequestException as e:
                self.log_test(f"{test_name} - Network", False, f"Network error: {str(e)}")
            except Exception as e:
                self.log_test(f"{test_name} - General", False, f"Unexpected error: {str(e)}")
    
    def test_image_urls(self):
        """Test that TMDB image URLs are accessible"""
        print("\n=== Testing Image URL Accessibility ===")
        
        try:
            # Get some movie data first
            response = self.session.get(f"{self.base_url}/movies/rows")
            if response.status_code != 200:
                self.log_test("Image URLs - Data Fetch", False, "Could not fetch movie data for URL testing")
                return
            
            data = response.json()
            image_urls = []
            
            # Collect some image URLs
            for row in data[:2]:  # Test first 2 rows only
                movies = row.get('movies', [])
                for movie in movies[:3]:  # Test first 3 movies per row
                    if movie.get('poster'):
                        image_urls.append(movie['poster'])
                    if len(image_urls) >= 5:  # Limit to 5 URLs for testing
                        break
                if len(image_urls) >= 5:
                    break
            
            if not image_urls:
                self.log_test("Image URLs - Collection", False, "No image URLs found to test")
                return
            
            self.log_test("Image URLs - Collection", True, f"Collected {len(image_urls)} URLs for testing")
            
            # Test each URL
            accessible_count = 0
            for i, url in enumerate(image_urls):
                try:
                    # Use HEAD request to check if URL is accessible
                    head_response = requests.head(url, timeout=5)
                    if head_response.status_code == 200:
                        accessible_count += 1
                        self.log_test(f"Image URL {i+1} - Accessibility", True, f"URL accessible: {url[:50]}...")
                    else:
                        self.log_test(f"Image URL {i+1} - Accessibility", False, f"Status {head_response.status_code}: {url[:50]}...")
                except requests.exceptions.RequestException as e:
                    self.log_test(f"Image URL {i+1} - Accessibility", False, f"Network error: {str(e)}")
            
            # Overall image accessibility
            success_rate = (accessible_count / len(image_urls)) * 100
            if success_rate >= 80:
                self.log_test("Image URLs - Overall", True, f"{accessible_count}/{len(image_urls)} URLs accessible ({success_rate:.1f}%)")
            else:
                self.log_test("Image URLs - Overall", False, f"Only {accessible_count}/{len(image_urls)} URLs accessible ({success_rate:.1f}%)")
            
        except Exception as e:
            self.log_test("Image URLs - General", False, f"Unexpected error: {str(e)}")
    
    def run_all_tests(self):
        """Run all backend tests"""
        print(f"🚀 Starting Netflix Clone Backend Tests")
        print(f"Backend URL: {self.base_url}")
        print("=" * 60)
        
        # Run all test suites
        self.test_featured_endpoint()
        self.test_movie_rows_endpoint()
        self.test_trailer_endpoint()
        self.test_image_urls()
        
        # Generate summary
        self.generate_summary()
    
    def generate_summary(self):
        """Generate test summary"""
        print("\n" + "=" * 60)
        print("🎬 NETFLIX CLONE BACKEND TEST SUMMARY")
        print("=" * 60)
        
        total_tests = len(self.test_results)
        passed_tests = len([t for t in self.test_results if t['passed']])
        failed_tests = total_tests - passed_tests
        
        print(f"Total Tests: {total_tests}")
        print(f"✅ Passed: {passed_tests}")
        print(f"❌ Failed: {failed_tests}")
        print(f"Success Rate: {(passed_tests/total_tests)*100:.1f}%")
        
        if failed_tests > 0:
            print(f"\n🔍 FAILED TESTS:")
            for test in self.test_results:
                if not test['passed']:
                    print(f"  ❌ {test['test']}: {test['message']}")
        
        print(f"\n📊 CRITICAL ENDPOINTS STATUS:")
        
        # Check critical endpoint status
        featured_working = any(t['test'].startswith('Featured - Status Code') and t['passed'] for t in self.test_results)
        rows_working = any(t['test'].startswith('Movie Rows - Status Code') and t['passed'] for t in self.test_results)
        trailer_working = any(t['test'].endswith('Trailer - Status Code') and t['passed'] for t in self.test_results)
        
        print(f"  /api/featured: {'✅ Working' if featured_working else '❌ Failed'}")
        print(f"  /api/movies/rows: {'✅ Working' if rows_working else '❌ Failed'}")
        print(f"  /api/movies/{{id}}/trailer: {'✅ Working' if trailer_working else '❌ Failed'}")
        
        # Overall status
        critical_endpoints_working = featured_working and rows_working and trailer_working
        
        if critical_endpoints_working and failed_tests <= 2:
            print(f"\n🎉 OVERALL STATUS: ✅ BACKEND IS WORKING")
            print("All critical endpoints are functional!")
        elif critical_endpoints_working:
            print(f"\n⚠️  OVERALL STATUS: ⚠️ BACKEND MOSTLY WORKING")
            print("Critical endpoints work but some issues detected.")
        else:
            print(f"\n💥 OVERALL STATUS: ❌ BACKEND HAS ISSUES")
            print("One or more critical endpoints are failing.")
        
        return critical_endpoints_working and failed_tests <= 2

if __name__ == "__main__":
    tester = NetflixBackendTester()
    success = tester.run_all_tests()
    
    # Exit with appropriate code
    sys.exit(0 if success else 1)