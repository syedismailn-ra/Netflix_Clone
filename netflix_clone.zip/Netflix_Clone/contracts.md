# Netflix Clone - Backend Integration Contracts

## API Contracts

### 1. Get Featured Content
**Endpoint:** `GET /api/featured`
**Description:** Fetch a featured movie/show for the hero section
**Response:**
```json
{
  "id": 1234,
  "title": "Movie Title",
  "description": "Movie description...",
  "backdrop": "https://image.tmdb.org/t/p/original/...",
  "logo": "https://image.tmdb.org/t/p/original/...",
  "rating": "PG-13",
  "year": "2023",
  "genres": ["Action", "Drama"],
  "trailer": "youtube_video_id"
}
```

### 2. Get Movie Rows
**Endpoint:** `GET /api/movies/rows`
**Description:** Fetch multiple movie categories (trending, popular, top-rated, action)
**Response:**
```json
[
  {
    "id": 1,
    "title": "Trending Now",
    "movies": [
      {
        "id": 123,
        "title": "Movie Title",
        "poster": "https://image.tmdb.org/t/p/w500/...",
        "backdrop": "https://image.tmdb.org/t/p/original/...",
        "rating": 8.5,
        "year": 2023,
        "trailer": "youtube_video_id"
      }
    ]
  }
]
```

### 3. Get Movie Details with Trailer
**Endpoint:** `GET /api/movies/{movie_id}`
**Description:** Get detailed info including trailer URL
**Response:**
```json
{
  "id": 123,
  "title": "Movie Title",
  "description": "Description...",
  "poster": "url",
  "backdrop": "url",
  "rating": 8.5,
  "year": 2023,
  "genres": ["Action"],
  "trailer": "youtube_video_id"
}
```

## TMDB API Integration

### TMDB Endpoints to Use:
1. **Trending:** `/trending/all/week` - Get trending movies/shows
2. **Popular:** `/movie/popular` - Get popular movies
3. **Top Rated:** `/movie/top_rated` - Get top rated movies
4. **Action:** `/discover/movie?with_genres=28` - Action movies (genre 28)
5. **Videos:** `/movie/{id}/videos` - Get trailers/videos for a movie
6. **TV Shows:** `/tv/popular` - Popular TV shows

### TMDB API Key:
Using the provided keys: `c8dea14dc917687ac631a52620e4f7ad` (with rotation support)

## Mock Data to Replace

**File:** `/app/frontend/src/mock.js`
- `mockFeaturedContent` - Will be replaced with API call to `/api/featured`
- `mockMovieRows` - Will be replaced with API call to `/api/movies/rows`

## Backend Implementation Plan

### Models (models.py)
- No database models needed - using TMDB API directly
- Cache TMDB responses for performance (optional)

### Services (tmdb_service.py)
- `get_trending_content()` - Fetch trending movies/shows
- `get_popular_movies()` - Fetch popular movies
- `get_top_rated_movies()` - Fetch top rated movies
- `get_action_movies()` - Fetch action movies
- `get_movie_trailer(movie_id)` - Fetch YouTube trailer ID
- `get_featured_content()` - Get a featured movie for hero section
- `format_movie_data(tmdb_movie)` - Format TMDB data to our structure

### Routes (server.py)
- `GET /api/featured` - Returns featured content for hero
- `GET /api/movies/rows` - Returns all movie rows
- `GET /api/movies/{movie_id}` - Returns specific movie details

## Frontend Integration Changes

### Files to Update:
1. **HomePage.jsx**
   - Remove mock imports
   - Add useEffect to fetch from `/api/featured` and `/api/movies/rows`
   - Handle loading states
   - Handle errors

### Example Frontend Code:
```javascript
const [featuredContent, setFeaturedContent] = useState(null);
const [movieRows, setMovieRows] = useState([]);
const [loading, setLoading] = useState(true);

useEffect(() => {
  const fetchData = async () => {
    try {
      const [featuredRes, rowsRes] = await Promise.all([
        axios.get(`${API}/featured`),
        axios.get(`${API}/movies/rows`)
      ]);
      setFeaturedContent(featuredRes.data);
      setMovieRows(rowsRes.data);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };
  fetchData();
}, []);
```

## Error Handling

### Backend:
- Handle TMDB API rate limits (rotate keys if needed)
- Return proper error codes (404, 500)
- Log errors for debugging

### Frontend:
- Show loading skeleton while fetching
- Show error message if API fails
- Fallback to mock data if needed

## Testing Checklist

- [ ] Featured content loads on homepage
- [ ] All movie rows display correctly
- [ ] Movie posters load without broken images
- [ ] Trailer modal opens with correct YouTube video
- [ ] Hover effects work on movie cards
- [ ] No console errors
- [ ] All TMDB images are accessible
