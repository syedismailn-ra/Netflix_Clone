// Mock data for Netflix clone
export const mockFeaturedContent = {
  id: 1,
  title: "Stranger Things",
  description: "When a young boy vanishes, a small town uncovers a mystery involving secret experiments, terrifying supernatural forces and one strange little girl.",
  backdrop: "https://image.tmdb.org/t/p/original/56v2KjBlU4XaOv9rVYEQypROD7P.jpg",
  logo: "https://image.tmdb.org/t/p/original/4j0PJOqjGEhgNcGFxBaDUvR6eh3.png",
  rating: "TV-14",
  year: "2016",
  seasons: "4 Seasons",
  genres: ["Sci-Fi", "Horror", "Drama"],
  trailer: "b9EkMc79ZSU"
};

export const mockMovieRows = [
  {
    id: 1,
    title: "Trending Now",
    movies: [
      {
        id: 1,
        title: "The Dark Knight",
        poster: "https://image.tmdb.org/t/p/w500/qJ2tW6WMUDux911r6m7haRef0WH.jpg",
        backdrop: "https://image.tmdb.org/t/p/original/hkBaDkMWbLaf8B1lsWsKX7Ew3Xq.jpg",
        rating: 9.0,
        year: 2008,
        trailer: "EXeTwQWrcwY"
      },
      {
        id: 2,
        title: "Inception",
        poster: "https://image.tmdb.org/t/p/w500/oYuLEt3zVCKq57qu2F8dT7NIa6f.jpg",
        backdrop: "https://image.tmdb.org/t/p/original/s3TBrRGB1iav7gFOCNx3H31MoES.jpg",
        rating: 8.8,
        year: 2010,
        trailer: "YoHD9XEInc0"
      },
      {
        id: 3,
        title: "Interstellar",
        poster: "https://image.tmdb.org/t/p/w500/gEU2QniE6E77NI6lCU6MxlNBvIx.jpg",
        backdrop: "https://image.tmdb.org/t/p/original/xu9zaAevzQ5nnrsXN6JcahLnG4i.jpg",
        rating: 8.6,
        year: 2014,
        trailer: "zSWdZVtXT7E"
      },
      {
        id: 4,
        title: "The Matrix",
        poster: "https://image.tmdb.org/t/p/w500/f89U3ADr1oiB1s9GkdPOEpXUk5H.jpg",
        backdrop: "https://image.tmdb.org/t/p/original/icmmSD4vTTDKOq2vvdulafOGw93.jpg",
        rating: 8.7,
        year: 1999,
        trailer: "vKQi3bBA1y8"
      },
      {
        id: 5,
        title: "Pulp Fiction",
        poster: "https://image.tmdb.org/t/p/w500/d5iIlFn5s0ImszYzBPb8JPIfbXD.jpg",
        backdrop: "https://image.tmdb.org/t/p/original/suaEOtk1N1sgg2MTM7oZd2cfVp3.jpg",
        rating: 8.9,
        year: 1994,
        trailer: "s7EdQ4FqbhY"
      },
      {
        id: 6,
        title: "Fight Club",
        poster: "https://image.tmdb.org/t/p/w500/pB8BM7pdSp6B6Ih7QZ4DrQ3PmJK.jpg",
        backdrop: "https://image.tmdb.org/t/p/original/hZkgoQYus5vegHoetLkCJzb17zJ.jpg",
        rating: 8.8,
        year: 1999,
        trailer: "qtRKdVHc-cE"
      }
    ]
  },
  {
    id: 2,
    title: "Popular on Netflix",
    movies: [
      {
        id: 7,
        title: "Breaking Bad",
        poster: "https://image.tmdb.org/t/p/w500/ztkUQFLlC19CCMYHW9o1zWhJRNq.jpg",
        backdrop: "https://image.tmdb.org/t/p/original/tsRy63Mu5cu8etL1X7ZLyf7UP1M.jpg",
        rating: 9.5,
        year: 2008,
        trailer: "HhesaQXLuRY"
      },
      {
        id: 8,
        title: "The Shawshank Redemption",
        poster: "https://image.tmdb.org/t/p/w500/q6y0Go1tsGEsmtFryDOJo3dEmqu.jpg",
        backdrop: "https://image.tmdb.org/t/p/original/kXfqcdQKsToO0OUXHcrrNCHDBzO.jpg",
        rating: 9.3,
        year: 1994,
        trailer: "6hB3S9bIaco"
      },
      {
        id: 9,
        title: "Forrest Gump",
        poster: "https://image.tmdb.org/t/p/w500/arw2vcBveWOVZr6pxd9XTd1TdQa.jpg",
        backdrop: "https://image.tmdb.org/t/p/original/3h1JZGDhZ8nzxdgvkxha0qBqi05.jpg",
        rating: 8.8,
        year: 1994,
        trailer: "bLvqoHBptjg"
      },
      {
        id: 10,
        title: "The Godfather",
        poster: "https://image.tmdb.org/t/p/w500/3bhkrj58Vtu7enYsRolD1fZdja1.jpg",
        backdrop: "https://image.tmdb.org/t/p/original/tmU7GeKVybMWFButWEGl2M4GeiP.jpg",
        rating: 9.2,
        year: 1972,
        trailer: "sY1S34973zA"
      },
      {
        id: 11,
        title: "Avatar",
        poster: "https://image.tmdb.org/t/p/w500/jRXYjXNq0Cs2TcJjLkki24MLp7u.jpg",
        backdrop: "https://image.tmdb.org/t/p/original/o0s4XsEDfDlvit5pDRKjzXR4pp2.jpg",
        rating: 7.8,
        year: 2009,
        trailer: "5PSNL1qE6VY"
      },
      {
        id: 12,
        title: "Gladiator",
        poster: "https://image.tmdb.org/t/p/w500/ty8TGRuvJLPUmAR1H1nRIsgwvim.jpg",
        backdrop: "https://image.tmdb.org/t/p/original/xT8xPpC9x4LdKsC0pFXgPRSMT1U.jpg",
        rating: 8.5,
        year: 2000,
        trailer: "owK1qxDselE"
      }
    ]
  },
  {
    id: 3,
    title: "Top Rated",
    movies: [
      {
        id: 13,
        title: "The Lord of the Rings",
        poster: "https://image.tmdb.org/t/p/w500/6oom5QYQ2yQTMJIbnvbkBL9cHo6.jpg",
        backdrop: "https://image.tmdb.org/t/p/original/s8NC4zVKYP2FAgs1fYSKg5ycpL0.jpg",
        rating: 8.9,
        year: 2001,
        trailer: "V75dMMIW2B4"
      },
      {
        id: 14,
        title: "Schindler's List",
        poster: "https://image.tmdb.org/t/p/w500/sF1U4EUQS8YHUYjNl3pMGNIQyr0.jpg",
        backdrop: "https://image.tmdb.org/t/p/original/k2FTJdmGMWWMXSnx2RQbt3S1bEg.jpg",
        rating: 9.0,
        year: 1993,
        trailer: "gG22XNhtnoY"
      },
      {
        id: 15,
        title: "12 Angry Men",
        poster: "https://image.tmdb.org/t/p/w500/ow3wq89wM8qd5X7hWKxiRfsFf9C.jpg",
        backdrop: "https://image.tmdb.org/t/p/original/qqHQsStV6exghCM7zbObuYBiYxw.jpg",
        rating: 9.0,
        year: 1957,
        trailer: "fSG38tk6TpI"
      },
      {
        id: 16,
        title: "The Green Mile",
        poster: "https://image.tmdb.org/t/p/w500/8VG8fDNiy50H4FedGwdSVUPoaJe.jpg",
        backdrop: "https://image.tmdb.org/t/p/original/l6hQWH9eDksNJNiXWYRkWqikOdu.jpg",
        rating: 8.6,
        year: 1999,
        trailer: "Ki4haFrqSrw"
      },
      {
        id: 17,
        title: "Goodfellas",
        poster: "https://image.tmdb.org/t/p/w500/aKuFiU82s5ISJpGZp7YkIr3kCUd.jpg",
        backdrop: "https://image.tmdb.org/t/p/original/jDwhpILmNtNvtdPFmRbcXq5WKSC.jpg",
        rating: 8.7,
        year: 1990,
        trailer: "qo5jJpHtI1Y"
      },
      {
        id: 18,
        title: "The Prestige",
        poster: "https://image.tmdb.org/t/p/w500/tRNlZbgNCNOpLpbPEz5L8G8A0JN.jpg",
        backdrop: "https://image.tmdb.org/t/p/original/85qhKRs2e4gBZkPQdK6S2MYDyqm.jpg",
        rating: 8.5,
        year: 2006,
        trailer: "o4gHCmTQDVI"
      }
    ]
  },
  {
    id: 4,
    title: "Action & Adventure",
    movies: [
      {
        id: 19,
        title: "Mad Max: Fury Road",
        poster: "https://image.tmdb.org/t/p/w500/hA2ple9q4qnwxp3hKVNhroipsir.jpg",
        backdrop: "https://image.tmdb.org/t/p/original/tbhdm8UJAb4ViCTsulYFL3lxMCd.jpg",
        rating: 8.1,
        year: 2015,
        trailer: "hEJnMQG9ev8"
      },
      {
        id: 20,
        title: "John Wick",
        poster: "https://image.tmdb.org/t/p/w500/fZPSd91yGE9fCcCe6OoQr6E3Bev.jpg",
        backdrop: "https://image.tmdb.org/t/p/original/umC04Cozevu8nn3JTDJ1pc7PVTn.jpg",
        rating: 7.4,
        year: 2014,
        trailer: "v2IVI8d-C-g"
      },
      {
        id: 21,
        title: "Die Hard",
        poster: "https://image.tmdb.org/t/p/w500/yFihWxQcmqcaBR31QM6Y8gT6aYV.jpg",
        backdrop: "https://image.tmdb.org/t/p/original/17zArExB7ztm6fjUXZwQWgGMC9f.jpg",
        rating: 8.2,
        year: 1988,
        trailer: "QIOX44m8ktc"
      },
      {
        id: 22,
        title: "Terminator 2",
        poster: "https://image.tmdb.org/t/p/w500/5M0j0B18abtBI5gi2RhfjjurTqb.jpg",
        backdrop: "https://image.tmdb.org/t/p/original/d9lth8eVvyVGoQ8QqwTd8xHgbE8.jpg",
        rating: 8.6,
        year: 1991,
        trailer: "CRRlbK5w8AE"
      },
      {
        id: 23,
        title: "Avengers: Endgame",
        poster: "https://image.tmdb.org/t/p/w500/or06FN3Dka5tukK1e9sl16pB3iy.jpg",
        backdrop: "https://image.tmdb.org/t/p/original/7RyHsO4yDXtBv1zUU3mTpHeQ0d5.jpg",
        rating: 8.4,
        year: 2019,
        trailer: "TcMBFSGVi1c"
      },
      {
        id: 24,
        title: "Skyfall",
        poster: "https://image.tmdb.org/t/p/w500/11mOcQCZXIEuJGcGffdmkzOKcYd.jpg",
        backdrop: "https://image.tmdb.org/t/p/original/qJxzjUjCpTPvDHldNnlbRC4OqEh.jpg",
        rating: 7.8,
        year: 2012,
        trailer: "6kw1UVovByw"
      }
    ]
  }
];