import React, { useState, useEffect } from 'react';
import { Search, Bell, User } from 'lucide-react';

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 0);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-[#141414]' : 'bg-gradient-to-b from-black/80 to-transparent'
      }`}
    >
      <div className="flex items-center justify-between px-8 py-4">
        {/* Left Section */}
        <div className="flex items-center gap-8">
          {/* Logo */}
          <h1 className="text-[#E50914] text-3xl font-bold tracking-tight">
            NETFLIX
          </h1>

          {/* Navigation Links */}
          <div className="hidden md:flex items-center gap-6">
            <a
              href="#"
              className="text-white hover:text-gray-300 transition-colors font-medium"
            >
              Home
            </a>
            <a
              href="#"
              className="text-gray-300 hover:text-white transition-colors"
            >
              TV Shows
            </a>
            <a
              href="#"
              className="text-gray-300 hover:text-white transition-colors"
            >
              Movies
            </a>
            <a
              href="#"
              className="text-gray-300 hover:text-white transition-colors"
            >
              New & Popular
            </a>
            <a
              href="#"
              className="text-gray-300 hover:text-white transition-colors"
            >
              My List
            </a>
          </div>
        </div>

        {/* Right Section */}
        <div className="flex items-center gap-6">
          <button className="text-white hover:text-gray-300 transition-colors">
            <Search className="h-6 w-6" />
          </button>
          <button className="text-white hover:text-gray-300 transition-colors">
            <Bell className="h-6 w-6" />
          </button>
          <button className="flex items-center gap-2 text-white hover:text-gray-300 transition-colors">
            <div className="w-8 h-8 bg-[#E50914] rounded flex items-center justify-center">
              <User className="h-5 w-5" />
            </div>
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;