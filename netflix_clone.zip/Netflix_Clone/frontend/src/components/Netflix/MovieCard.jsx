import React, { useState } from 'react';
import { Play } from 'lucide-react';

const MovieCard = ({ movie, onPlayTrailer }) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div
      className="relative flex-shrink-0 w-[280px] cursor-pointer transition-all duration-300 ease-in-out"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={() => onPlayTrailer(movie)}
    >
      <div
        className={`relative overflow-hidden rounded-md transition-all duration-300 ${
          isHovered ? 'scale-110 z-20 shadow-2xl' : 'scale-100 z-10'
        }`}
      >
        {/* Movie Poster */}
        <img
          src={movie.poster}
          alt={movie.title}
          className="w-full h-[420px] object-cover"
          onError={(e) => {
            e.target.style.display = 'none';
            if (e.target.nextSibling) {
              e.target.nextSibling.style.display = 'flex';
            }
          }}
        />
        <div className="hidden w-full h-[420px] bg-[#181818] items-center justify-center">
          <span className="text-white text-center p-4">{movie.title}</span>
        </div>

        {/* Hover Overlay */}
        {isHovered && (
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent flex flex-col justify-end p-4 animate-in fade-in duration-200">
            <div className="space-y-2">
              <h3 className="text-white font-bold text-lg line-clamp-2">
                {movie.title}
              </h3>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-green-500 font-semibold text-sm">
                    {movie.rating} ★
                  </span>
                  <span className="text-gray-400 text-sm">{movie.year}</span>
                </div>
                <button className="bg-white rounded-full p-2 hover:bg-white/90 transition-all">
                  <Play className="h-4 w-4 text-black fill-black" />
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default MovieCard;