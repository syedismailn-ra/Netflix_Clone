import React from 'react';
import { Play, Info } from 'lucide-react';
import { Button } from '../ui/button';

const HeroSection = ({ content, onPlayTrailer }) => {
  return (
    <div className="relative h-[80vh] w-full">
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src={content.backdrop}
          alt={content.title}
          className="w-full h-full object-cover"
          onError={(e) => {
            e.target.style.display = 'none';
          }}
        />
        {/* Gradient Overlays */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#141414] via-transparent to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#141414] via-transparent to-transparent" />
      </div>

      {/* Content */}
      <div className="relative h-full flex items-center">
        <div className="max-w-7xl mx-auto px-8 w-full">
          <div className="max-w-2xl space-y-4">
            {/* Logo/Title */}
            {content.logo ? (
              <img
                src={content.logo}
                alt={content.title}
                className="w-full max-w-md mb-4"
                onError={(e) => {
                  e.target.style.display = 'none';
                  e.target.nextSibling.style.display = 'block';
                }}
              />
            ) : null}
            <h1 className="text-5xl md:text-6xl font-bold text-white">
              {content.title}
            </h1>

            {/* Meta Info */}
            <div className="flex items-center gap-4 text-white">
              <span className="text-green-500 font-semibold">{content.rating}</span>
              <span>{content.year}</span>
              {content.seasons && <span>{content.seasons}</span>}
            </div>

            {/* Genres */}
            <div className="flex gap-2">
              {content.genres?.map((genre, index) => (
                <span key={index} className="text-white text-sm">
                  {genre}{index < content.genres.length - 1 ? ' •' : ''}
                </span>
              ))}
            </div>

            {/* Description */}
            <p className="text-white text-lg md:text-xl max-w-xl leading-relaxed">
              {content.description}
            </p>

            {/* Buttons */}
            <div className="flex gap-3 pt-4">
              <Button
                onClick={() => onPlayTrailer(content)}
                className="bg-white text-black hover:bg-white/90 font-semibold px-8 py-6 text-lg rounded transition-all duration-200"
              >
                <Play className="mr-2 h-6 w-6 fill-black" />
                Play
              </Button>
              <Button
                variant="secondary"
                className="bg-gray-500/70 text-white hover:bg-gray-500/50 font-semibold px-8 py-6 text-lg rounded transition-all duration-200"
              >
                <Info className="mr-2 h-6 w-6" />
                More Info
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HeroSection;