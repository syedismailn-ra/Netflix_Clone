import React from 'react';
import { X } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '../ui/dialog';

const TrailerModal = ({ isOpen, onClose, movie }) => {
  if (!movie) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-5xl bg-[#181818] border-none p-0 overflow-hidden">
        <DialogHeader className="absolute top-4 right-4 z-50">
          <button
            onClick={onClose}
            className="bg-[#181818] rounded-full p-2 hover:bg-[#282828] transition-colors"
          >
            <X className="h-6 w-6 text-white" />
          </button>
        </DialogHeader>

        {/* YouTube Player */}
        <div className="relative w-full" style={{ paddingTop: '56.25%' }}>
          <iframe
            className="absolute inset-0 w-full h-full"
            src={`https://www.youtube.com/embed/${movie.trailer}?autoplay=1&rel=0`}
            title={movie.title}
            frameBorder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          />
        </div>

        {/* Movie Info */}
        <div className="p-8 space-y-4">
          <DialogTitle className="text-white text-3xl font-bold">
            {movie.title}
          </DialogTitle>
          
          <div className="flex items-center gap-4 text-white">
            {movie.rating && (
              <span className="text-green-500 font-semibold">
                {movie.rating} ★
              </span>
            )}
            {movie.year && <span className="text-gray-400">{movie.year}</span>}
          </div>

          {movie.description && (
            <p className="text-gray-300 text-lg leading-relaxed">
              {movie.description}
            </p>
          )}

          {movie.genres && (
            <div className="flex gap-2">
              {movie.genres.map((genre, index) => (
                <span key={index} className="text-white text-sm">
                  {genre}{index < movie.genres.length - 1 ? ' •' : ''}
                </span>
              ))}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default TrailerModal;