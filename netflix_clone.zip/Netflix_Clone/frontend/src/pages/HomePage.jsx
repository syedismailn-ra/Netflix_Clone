import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Navbar from '../components/Netflix/Navbar';
import HeroSection from '../components/Netflix/HeroSection';
import MovieRow from '../components/Netflix/MovieRow';
import TrailerModal from '../components/Netflix/TrailerModal';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const HomePage = () => {
  const [featuredContent, setFeaturedContent] = useState(null);
  const [movieRows, setMovieRows] = useState([]);
  const [selectedMovie, setSelectedMovie] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const [featuredRes, rowsRes] = await Promise.all([
          axios.get(`${API}/featured`),
          axios.get(`${API}/movies/rows`)
        ]);
        
        setFeaturedContent(featuredRes.data);
        setMovieRows(rowsRes.data);
        setError(null);
      } catch (error) {
        console.error('Error fetching data:', error);
        setError('Failed to load content. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const handlePlayTrailer = async (movie) => {
    // If trailer is not loaded yet, fetch it
    if (!movie.trailer) {
      try {
        const mediaType = movie.seasons ? 'tv' : 'movie';
        const trailerRes = await axios.get(`${API}/movies/${movie.id}/trailer?media_type=${mediaType}`);
        movie.trailer = trailerRes.data.trailer;
      } catch (error) {
        console.error('Error fetching trailer:', error);
      }
    }
    
    setSelectedMovie(movie);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setTimeout(() => setSelectedMovie(null), 300);
  };

  if (loading) {
    return (
      <div className="bg-[#141414] min-h-screen flex items-center justify-center">
        <div className="text-white text-2xl">Loading...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-[#141414] min-h-screen flex items-center justify-center">
        <div className="text-white text-xl">{error}</div>
      </div>
    );
  }

  return (
    <div className="bg-[#141414] min-h-screen">
      <Navbar />
      
      {featuredContent && (
        <HeroSection
          content={featuredContent}
          onPlayTrailer={handlePlayTrailer}
        />
      )}

      {/* Movie Rows */}
      <div className="relative -mt-32 z-20 space-y-8 pb-16">
        {movieRows.map((row) => (
          <MovieRow
            key={row.id}
            title={row.title}
            movies={row.movies}
            onPlayTrailer={handlePlayTrailer}
          />
        ))}
      </div>

      {/* Trailer Modal */}
      <TrailerModal
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        movie={selectedMovie}
      />
    </div>
  );
};

export default HomePage;